function main() {

  (function () {
    'use strict';

    // ================= Smooth page scroll =================
    $('a.page-scroll').click(function () {
      if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
        var target = $(this.hash);
        target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
        if (target.length) {
          $('html,body').animate({
            scrollTop: target.offset().top - 40
          }, 900);
          return false;
        }
      }
    });

    // ================= Show Menu on Scroll =================
    $(window).bind('scroll', function () {
      var navHeight = $(window).height() - 500;
      if ($(window).scrollTop() > navHeight) {
        $('.navbar-default').addClass('on');
      } else {
        $('.navbar-default').removeClass('on');
      }
    });

    // ================= Scrollspy =================
    $('body').scrollspy({
      target: '.navbar-default',
      offset: 80
    });

    // ================= Hide nav on click =================
    $(".navbar-nav li a").click(function () {
      var toggle = $(".navbar-toggle").is(":visible");
      if (toggle) {
        $(".navbar-collapse").collapse('hide');
      }
    });
  });

    // ================= Isotope + Lightbox =================
    $(window).on('load', function () {
      var $container = $('.portfolio-items');
      $container.isotope({
        filter: '*',
        animationOptions: {
          duration: 750,
          easing: 'linear',
          queue: false
        }
      });

      // Nivo Lightbox
      $('.portfolio-item a').nivoLightbox({
        effect: 'slideDown',
        keyboardNav: true,
      });
    });

  }; // <-- self-invoking function को सही से close किया गया

main();
// jQuery example
$(window).scroll(function() {
  if ($(this).scrollTop() > 50) {  // scroll 50px ke baad
    $('#menu').addClass('on');
  } else {
    $('#menu').removeClass('on');
  }
});
// ===== PORTFOLIO FILTER FINAL FIX =====
$(window).on('load', function () {

  var $grid = $('.portfolio-items').isotope({
    itemSelector: '.portfolio-item',
    layoutMode: 'fitRows'
  });

  $('.portfolio-filters a').on('click', function (e) {
    e.preventDefault();

    $('.portfolio-filters a').removeClass('active');
    $(this).addClass('active');

    var filterValue = $(this).attr('data-filter');
    $grid.isotope({ filter: filterValue });
  });

});


